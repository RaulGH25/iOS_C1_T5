//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Raul Guerra Hernandez on 11/5/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelHamburguesa: UILabel!
    
    @IBOutlet weak var labelPais: UILabel!
    
    let colores = Colores();
    let hamburguesas = ColeccionDeHamburguesa();
    let paises = ColeccionDePaises();
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func newHamburguer() {
        
        let paisAleatorio = paises.obtenPais();
        let hamburguesaAleatoria = hamburguesas.obtenHamburguesa();
        
        labelHamburguesa.text = hamburguesaAleatoria;
        labelPais.text = paisAleatorio;
        
        print("button hitted")
        
        let colorAleatorio = colores.regresaColorAleatorio();
        view.backgroundColor = colorAleatorio;
        view.tintColor = colorAleatorio;
        
    }
    

}

