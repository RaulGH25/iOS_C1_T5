//
//  Datos.swift
//  Hamburguesas
//
//  Created by Raul Guerra Hernandez on 11/6/16.
//  Copyright © 2016 Raul Guerra Hernandez. All rights reserved.
//

import Foundation
import UIKit


struct Colores {
    
    let colores = [ UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
                    UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
                    UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
                    UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
                    UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
                    UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
                    UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
                    UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    func regresaColorAleatorio() -> UIColor {
        let posicion = Int(arc4random()) % colores.count
        
        return colores[posicion]
        
    }
}


struct Hamburguesas {
    
    let hamburguesas = [ "h1" , "h2", "h3"]
    
    func regresaHamburguesaAleatoria() -> String {
        let posicion = Int(arc4random()) % hamburguesas.count
        
        return hamburguesas[posicion]
        
    }
}



struct Paises {
    
    let paises = [ "p1" , "p2", "p3"]
    
    func regresaPaisAleatoria() -> String {
        let posicion = Int(arc4random()) % paises.count
        
        return paises[posicion]
        
    }
}








class ColeccionDeHamburguesa {
    
    let hamburguesas = [ "Korzo Fried Burger" , "Jalapeño Bacon Cheeseburger", "Hamburgão", "Latin Macho Burger", "Green Chile Cheeseburger", "Tostón Burger", "Kuma Burger", "Astronaut Burger", "Frita Cubana", "Crispy Cheese", "Schwartz’s burguer", "Burgermeister,", "Honest Burger", "H. Jugosa", "H. Horney", "H. Veggie", "H. Mariachi", "Cuarto de libra", "BigKing", "Mc Chicken"]
    
    func obtenHamburguesa() -> String {
        let posicion = Int(arc4random()) % hamburguesas.count
        
        return hamburguesas[posicion]
        
    }
}


class ColeccionDePaises{

    let paises = [ "España", "Mexico", "Estados Unidos", "Reino Unido", "Suiza", "Japón", "China", "Grecia", "Islandia", "Polonia", "Rusia", "Egipto", "Argentina", "Peru", "Israel", "Pakistán", "India", "Marruecos", "Senegal", "Sudáfrica"]
    
    func obtenPais() -> String {
        let posicion = Int(arc4random()) % paises.count
        
        return paises[posicion]
        
    }
}


